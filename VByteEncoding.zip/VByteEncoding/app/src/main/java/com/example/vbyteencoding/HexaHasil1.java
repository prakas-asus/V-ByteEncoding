package com.example.vbyteencoding;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class HexaHasil1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hexa_hasil);
        TextView hasilHex = (TextView) findViewById(R.id.hasilhex);
        Intent i = getIntent();
        Bundle b = i.getExtras();
        if(b!=null){
            String j = String.valueOf(b.get("hasilhex"));
            hasilHex.setText(j);
        }
        Button exit = (Button) findViewById(R.id.exitmenu);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii=new Intent(HexaHasil1.this, MainActivity.class);
                startActivity(ii);
            }
        });
    }
}