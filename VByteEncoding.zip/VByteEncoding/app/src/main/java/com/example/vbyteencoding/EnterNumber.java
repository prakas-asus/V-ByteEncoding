package com.example.vbyteencoding;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Scanner;

public class EnterNumber extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_number);
        final EditText inpuTextView = (EditText) findViewById(R.id.inputDesimal);
        final Button hitungBin = (Button) findViewById(R.id.counbin);
        hitungBin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inpuTextView.getText().toString().equals("")){
                    inpuTextView.setError("Masukan Angka");
                }else if(inpuTextView.getText().toString().length() > 9){
                    inpuTextView.setError("Angka lebih dari kapasitas");
                }else{
                    Intent intent = new Intent(EnterNumber.this, BinnerHasil.class);
                    intent.putExtra("hasil", hasil(inpuTextView.getText().toString()));
                    startActivity(intent);
                }
            }
        });
    }
    public static String hasil(String code){
        int binnum, rem;
        String hexdecnum = "";

        // digits in hexadecimal number system
        EnterNumber ubah = new EnterNumber();
        char hex[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

        // declarasi biner
        Scanner input = new Scanner(System.in);
        int nilaiV = 0;
        int size = 0;
        String result = "", nilai = "";
        ArrayList<String> arr = new ArrayList<String>();
        ArrayList<String> arr1 = new ArrayList<String>();
        int[] conv = new int[4];

        // input
//        System.out.print("Masukan Input :");
        nilaiV = Integer.valueOf(String.valueOf(code));
        result = Integer.toBinaryString(nilaiV);

        for (int i = 0; i < result.length(); i++) {
            arr.add(String.valueOf(result.charAt(i)));
        }

        for (int i = 0; i < arr.size(); i++) {
            // System.out.print(arr.get(i));
        }

        System.out.println();

        for (int i = arr.size(); i < 21; i++) {
            arr.add(0, "0");
        }
        for (int i = arr.size() - 1; i >= 0; i--) {
            arr1.add(arr.get(i));
        }
        for (int i = 0; i < arr1.size(); i++) {
            if (i == 7) {
                arr1.add(i, "1");
            } else if (i % 7 == 0 && i != 7 && i != 0) {
                arr1.add(i, "0");
            }
        }

        for (int i = arr1.size() - 1; i >= 0; i--) {
            nilai += "" + arr1.get(i);
        }
//        System.out.println("nilainya " + nilai);
//        System.out.println("nilai Dibag menjadi perdelapan digit :");
        if (result.length() < 8) {
            code = String.valueOf(nilai.substring(16, 24));
            return code;
//            System.out.println(nilai.substring(16, 24) + " Nilai Hexa "
//                    + ubah.decimalToHex(Integer.valueOf(nilai.substring(16, 24))));
        } else if (result.length() < 15) {
            code = String.valueOf(nilai.substring(8, 16) + " " + String.valueOf(nilai.substring(16, 24)));
            return code;
//            System.out.println(nilai.substring(8, 16) + " Nilai Hexa "
//                    + ubah.decimalToHex(Integer.valueOf(nilai.substring(8, 16))));
//            System.out.println(nilai.substring(16, 24) + " Nilai Hexa "
//                    + ubah.decimalToHex(Integer.valueOf(nilai.substring(16, 24))));
        } else if (result.length() < 24) {
            code = String.valueOf(nilai.substring(0, 8) + " " + String.valueOf(nilai.substring(8, 16) + " " + String.valueOf(nilai.substring(16, 24))));
            return code;
//            System.out.println(
//                    nilai.substring(0, 8) + " Nilai Hexa " + ubah.decimalToHex(Integer.valueOf(nilai.substring(0, 8))));
//            System.out.println(nilai.substring(8, 16) + " Nilai Hexa "
//                    + ubah.decimalToHex(Integer.valueOf(nilai.substring(8, 16))));
//            System.out.println(nilai.substring(16, 24) + " Nilai Hexa "
//                    + ubah.decimalToHex(Integer.valueOf(nilai.substring(16, 24))));
        }
        return code;
    }
}